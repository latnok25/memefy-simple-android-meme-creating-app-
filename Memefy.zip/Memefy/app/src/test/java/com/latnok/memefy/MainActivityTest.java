package com.latnok.memefy;

import junit.framework.TestCase;

/**
 * Created by k on 7/6/2017.
 */
public class MainActivityTest extends TestCase {

}